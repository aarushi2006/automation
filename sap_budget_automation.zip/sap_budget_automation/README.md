# SAP Budget Utilization Automation

Modularized, object-oriented version of the original single-file script.
Functionality is unchanged — only structure, naming, and logging were improved.

## Project Structure

```
sap_budget_automation/
├── main.py                    # Entry point — orchestrates the full run
├── config.py                  # AppConfig — all paths & constants
├── logger_setup.py            # LoggerFactory — console + timestamped .txt log
├── quarter_calculator.py      # QuarterCalculator — fiscal quarter logic
├── credentials_manager.py     # CredentialsManager — reads credentials workbook
├── state_manager.py           # RunStateManager — last_run.txt / last_percent.txt
├── sap_report_downloader.py   # SapReportDownloader — Playwright SAP automation
├── excel_master_manager.py    # ExcelMasterManager — Master.xlsx read/write
├── email_notifier.py          # EmailNotifier — Outlook email composition/send
├── notification_dialog.py     # NotificationDialog — completion popup
└── requirements.txt
```

## Design Notes

- **One class, one responsibility.** Each module owns exactly one part of the
  pipeline (SAP scraping, workbook updates, email, state, logging).
- **Naming conventions** follow standard Python (PEP 8):
  - `PascalCase` for classes (`SapReportDownloader`, `ExcelMasterManager`)
  - `snake_case` for functions, methods, and variables
  - `UPPER_SNAKE_CASE` for class-level constants (e.g. `PASTE_RETRY_ATTEMPTS`)
  - Private/internal helper methods are prefixed with a single underscore
    (e.g. `_login`, `_export_report`)
- **Dependency injection.** `AppConfig` and the shared `logger` are constructed
  once in `main.py` and passed into every class, instead of each module
  reaching for global state. This makes each class independently testable.
- **No behavior changes.** Selectors, sleep timings, cell references, and the
  email formatting logic are preserved exactly as in the original script.

## Logging

Every run creates a fresh log file at:

```
<app_folder>/logs/Budget_Report_DDMMYYYY_HHMMSS.txt
```

e.g. `Budget_Report_02072026_143512.txt` for a run on 2 July 2026 at 14:35:12.

The log captures every stage of the run (login, export, workbook update,
email dispatch) at DEBUG level in the file, and key milestones at INFO level
on the console. Errors are logged with full tracebacks via `logger.exception`.

## Running

```bash
pip install -r requirements.txt
playwright install msedge
python main.py
```

## Packaging as an .exe

If you package this with PyInstaller, make sure to bundle all `.py` modules
(PyInstaller will pick them up automatically via the `main.py` entry point)
and keep `credentials_somil.xlsx` / `Master.xlsx` alongside the built `.exe`,
exactly as with the original script.
