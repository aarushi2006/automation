"""
notification_dialog.py

Displays a native Windows message box to notify the user that automation has
completed. Dependency-free so it works reliably in a frozen (.exe) build.
"""

import ctypes


class NotificationDialog:
    """Shows a simple Windows MessageBox on successful completion."""

    @staticmethod
    def show_success(logger):
        """Displays a success MessageBox; logs a warning instead of failing if unavailable."""
        message = (
            "SAP Automation Completed Successfully!\n\n"
            "- SAP report downloaded\n"
            "- Master file updated\n"
            "- Email sent successfully\n\n"
            "You can now close this window."
        )
        try:
            ctypes.windll.user32.MessageBoxW(0, message, "Automation Status", 1)
        except Exception as error:
            logger.warning("Could not display success dialog: %s", error)
