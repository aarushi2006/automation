"""
state_manager.py

Manages persistence of run-state metadata (last run date and last utilization
percentage) between automation runs, using small text files.
"""

import os


class RunStateManager:
    """Reads and writes small persistent state values used across automation runs."""

    def __init__(self, last_run_file_path, last_percent_file_path, logger):
        self.last_run_file_path = last_run_file_path
        self.last_percent_file_path = last_percent_file_path
        self.logger = logger

    def get_last_run_date(self, default_value):
        """Returns the previously stored run date, or default_value if none exists."""
        if os.path.exists(self.last_run_file_path):
            with open(self.last_run_file_path, "r") as file_handle:
                return file_handle.read().strip()
        return default_value

    def save_last_run_date(self, date_string):
        """Persists the given date string as the last run date."""
        with open(self.last_run_file_path, "w") as file_handle:
            file_handle.write(date_string)
        self.logger.debug("Saved last run date: %s", date_string)

    def get_last_percent(self):
        """Returns the previously stored utilization percentage, or None if unset."""
        if os.path.exists(self.last_percent_file_path):
            with open(self.last_percent_file_path, "r") as file_handle:
                return file_handle.read().strip()
        return None

    def save_last_percent(self, percent_string):
        """Persists the given percentage string as the last utilization percentage."""
        with open(self.last_percent_file_path, "w") as file_handle:
            file_handle.write(percent_string)
        self.logger.debug("Saved last percent: %s", percent_string)
