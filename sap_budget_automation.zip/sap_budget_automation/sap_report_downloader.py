"""
sap_report_downloader.py

Automates login to the SAP GUI web portal and downloads the budget
utilization report as a spreadsheet, using Playwright browser automation.
"""

import time
from playwright.sync_api import sync_playwright

from quarter_calculator import QuarterCalculator


class SapReportDownloader:
    """Automates SAP web GUI navigation and report export via Playwright."""

    VARIANT_SELECTION_SETTLE_DELAY_SECONDS = 1

    def __init__(self, config, logger):
        self.config = config
        self.logger = logger

    def download_report(self, sap_password):
        """Logs into SAP, applies the current quarter filter, and downloads the report."""
        current_quarter = QuarterCalculator.get_current_quarter()
        self.logger.info("Starting SAP report download for quarter: %s", current_quarter)

        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(channel="msedge", headless=False)
            context = browser.new_context(accept_downloads=True)
            page = context.new_page()

            try:
                self._login(page, sap_password)
                self._open_transaction(page)
                self._apply_budget_period_filter(page, current_quarter)
                self._export_report(page)
                self.logger.info("SAP report downloaded successfully to %s", self.config.sap_file)
            finally:
                context.close()
                browser.close()

    def _login(self, page, sap_password):
        self.logger.debug("Navigating to SAP portal.")
        page.goto(self.config.sap_url)

        page.get_by_role("textbox", name="User Account").fill(self.config.sap_user_account)
        page.get_by_role("textbox", name="Password").fill(sap_password)
        page.get_by_role("button", name="Sign in").click()
        page.wait_for_load_state("networkidle")
        self.logger.debug("SAP login submitted.")

    def _open_transaction(self, page):
        self.logger.debug("Opening transaction: %s", self.config.sap_transaction_code)
        page.get_by_role("combobox").fill(self.config.sap_transaction_code)
        page.get_by_role("button", name="Execute").click()

        page.get_by_role("button", name="Get Variant...").click()
        page.get_by_role("button", name="Execute (F8)").click()
        page.get_by_text(self.config.sap_variant_name).click()
        page.get_by_role("button", name="Choose").click()

        # Allow the UI to settle after variant selection before interacting further.
        time.sleep(self.VARIANT_SELECTION_SETTLE_DELAY_SECONDS)

    def _apply_budget_period_filter(self, page, current_quarter):
        self.logger.debug("Applying budget period filter: %s", current_quarter)
        page.wait_for_selector(self.config.budget_period_selector, state="visible")
        page.fill(self.config.budget_period_selector, current_quarter)
        page.get_by_role("button", name="Execute").click()

    def _export_report(self, page):
        self.logger.debug("Exporting report as spreadsheet.")
        page.get_by_role("button", name="Export").click()
        page.get_by_text("Spreadsheet").click()
        page.get_by_role("button", name="Export to...").click()

        with page.expect_download() as download_info:
            page.get_by_role("button", name="OK").click()

        download = download_info.value
        download.save_as(self.config.sap_file)
