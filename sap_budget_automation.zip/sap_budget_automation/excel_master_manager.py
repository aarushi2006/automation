"""
excel_master_manager.py

Handles all interactions with the Master.xlsx workbook:
  - Reading the calculated utilization percentage (via Excel COM, so formulas
    are evaluated).
  - Copying newly downloaded SAP data into the Raw_Report sheet.
  - Updating the Utilization Summary sheet with current run metadata.
"""

from datetime import date

import win32com.client as win32
from openpyxl import load_workbook


class ExcelMasterManager:
    """Coordinates read/write operations on the Master budget workbook."""

    def __init__(self, config, state_manager, logger):
        self.config = config
        self.state_manager = state_manager
        self.logger = logger

    def get_utilization_percentage(self):
        """Reads the calculated (formula-evaluated) value of cell F19 via Excel COM."""
        excel_app = win32.Dispatch("Excel.Application")
        excel_app.Visible = False

        workbook = excel_app.Workbooks.Open(self.config.master_file)
        worksheet = workbook.Sheets(self.config.master_sheet_utilization)
        cell_value = worksheet.Range("F19").Value

        workbook.Close(False)
        excel_app.Quit()

        if cell_value is not None:
            return f"{round(cell_value * 100)}%"
        return ""

    def update_master_with_sap_data(self):
        """Copies rows from the downloaded SAP report into the Master Raw_Report sheet
        and refreshes the Utilization Summary sheet."""
        self.logger.info("Copying SAP data into Master workbook.")

        old_percent = self.get_utilization_percentage()
        if old_percent:
            self.state_manager.save_last_percent(old_percent)

        sap_workbook = load_workbook(self.config.sap_file)
        sap_worksheet = sap_workbook[self.config.sap_sheet_data]

        master_workbook = load_workbook(self.config.master_file)
        master_worksheet = master_workbook[self.config.master_sheet_raw_report]

        master_worksheet.delete_rows(2, master_worksheet.max_row)

        row_count = 0
        for row in sap_worksheet.iter_rows(min_row=2, values_only=True):
            master_worksheet.append(row)
            row_count += 1
        self.logger.info("Copied %d rows into Raw_Report.", row_count)

        self._refresh_utilization_summary_sheet(master_workbook)
        master_workbook.save(self.config.master_file)

        self.logger.info("Master workbook updated and saved.")

    def _refresh_utilization_summary_sheet(self, master_workbook):
        summary_worksheet = master_workbook[self.config.master_sheet_utilization]
        today_string = date.today().strftime("%d-%m-%Y")

        last_run_date = self.state_manager.get_last_run_date(default_value=today_string)

        summary_worksheet["B2"] = (
            f"Revenue Budget Utilization Status as of  {today_string} | (All values in MRs)"
        )
        summary_worksheet["D21"] = f"Utilized Budget as of  {last_run_date}"

        self.state_manager.save_last_run_date(today_string)

        last_percent = self.state_manager.get_last_percent()
        if last_percent:
            summary_worksheet["F21"] = last_percent

        master_workbook.save(self.config.master_file)

        new_percent = self.get_utilization_percentage()
        if new_percent:
            self.state_manager.save_last_percent(new_percent)
