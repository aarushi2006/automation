"""
main.py

Entry point for the Budget Utilization Automation application.

Orchestrates the full flow:
  1. Load credentials
  2. Download the SAP budget report (Playwright)
  3. Update the Master workbook with the new data
  4. Send the status email (Outlook)
  5. Show a completion notification
"""

from config import AppConfig
from logger_setup import LoggerFactory
from credentials_manager import CredentialsManager
from state_manager import RunStateManager
from sap_report_downloader import SapReportDownloader
from excel_master_manager import ExcelMasterManager
from email_notifier import EmailNotifier
from notification_dialog import NotificationDialog


class BudgetAutomationApp:
    """Top-level orchestrator that wires together and runs the full automation flow."""

    def __init__(self):
        self.config = AppConfig()
        self.logger = LoggerFactory.create_logger(self.config.log_dir)

        self.state_manager = RunStateManager(
            self.config.last_run_file, self.config.last_percent_file, self.logger
        )
        self.credentials_manager = CredentialsManager(self.config.credentials_file, self.logger)
        self.sap_downloader = SapReportDownloader(self.config, self.logger)
        self.excel_manager = ExcelMasterManager(self.config, self.state_manager, self.logger)
        self.email_notifier = EmailNotifier(self.config, self.logger)

    def run(self):
        """Executes the end-to-end automation flow."""
        try:
            self.logger.info("=== Budget Automation Run Started ===")

            credentials = self.credentials_manager.load_credentials()
            self.sap_downloader.download_report(credentials["SAP_PASSWORD"])
            self.excel_manager.update_master_with_sap_data()
            self.email_notifier.send_utilization_report(credentials)

            NotificationDialog.show_success(self.logger)
            self.logger.info("=== Budget Automation Run Completed Successfully ===")

        except Exception as error:
            self.logger.exception("Automation run failed: %s", error)
            raise


if __name__ == "__main__":
    app = BudgetAutomationApp()
    app.run()
