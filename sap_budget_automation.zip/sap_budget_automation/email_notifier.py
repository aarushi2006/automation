"""
email_notifier.py

Builds and sends the budget utilization status email via Outlook, embedding
a formatted range copied directly from the Master workbook.
"""

import time
from datetime import date

import win32com.client as win32


class EmailNotifier:
    """Composes and sends the budget utilization report email through Outlook."""

    EMAIL_FONT_NAME = "Avenir Next LT Pro"
    EMAIL_FONT_SIZE = 10
    CLIPBOARD_STABILIZE_DELAY_SECONDS = 1.5
    EDITOR_WAIT_ATTEMPTS = 50
    EDITOR_WAIT_DELAY_SECONDS = 0.1
    SELECTION_SETTLE_DELAY_SECONDS = 1
    PASTE_RETRY_ATTEMPTS = 10
    PASTE_RETRY_DELAY_SECONDS = 0.5

    def __init__(self, config, logger):
        self.config = config
        self.logger = logger

    def send_utilization_report(self, credentials):
        """Copies the summary range from Master.xlsx and sends it as a formatted email."""
        subject = self._build_subject()
        self.logger.info("Preparing email: %s", subject)

        excel_app = win32.Dispatch("Excel.Application")
        excel_app.Visible = False
        excel_app.DisplayAlerts = False

        workbook = excel_app.Workbooks.Open(self.config.master_file)
        worksheet = workbook.Sheets(self.config.master_sheet_utilization)

        worksheet.Range("B2:F21").Copy()
        time.sleep(self.CLIPBOARD_STABILIZE_DELAY_SECONDS)

        mail_item = self._create_mail_item(credentials, subject)
        word_editor = self._wait_for_word_editor(mail_item)
        self._insert_greeting_and_table(word_editor)

        workbook.Close(False)
        excel_app.Quit()

        mail_item.Send()
        self.logger.info("Email sent successfully.")

    def _build_subject(self):
        today_string = date.today().strftime("%d %b'%y")
        return f"DE Revenue Budget Utilization Status | {today_string}"

    def _create_mail_item(self, credentials, subject):
        outlook_app = win32.Dispatch("Outlook.Application")
        mail_item = outlook_app.CreateItem(0)

        mail_item.SentOnBehalfOfName = credentials["FROM_EMAIL"]
        mail_item.To = credentials["TO_EMAIL"]
        if credentials.get("CC_EMAIL"):
            mail_item.CC = credentials["CC_EMAIL"]
        mail_item.Subject = subject
        mail_item.Display()

        return mail_item

    def _wait_for_word_editor(self, mail_item):
        inspector = mail_item.GetInspector
        for _ in range(self.EDITOR_WAIT_ATTEMPTS):
            try:
                editor = inspector.WordEditor
                if editor:
                    return editor
            except Exception:
                pass
            time.sleep(self.EDITOR_WAIT_DELAY_SECONDS)

        raise RuntimeError("Word editor did not become available in time.")

    def _insert_greeting_and_table(self, word_editor):
        greeting = (
            "Dear Sir/Ma'am,\n\n"
            "Please find below the Digital Enterprise revenue budget utilization "
            f"status as on {date.today().strftime('%d-%m-%Y')}.\n\n"
        )

        greeting_range = word_editor.Range(0, 0)
        greeting_range.InsertBefore(greeting)
        greeting_range.Font.Name = self.EMAIL_FONT_NAME
        greeting_range.Font.Size = self.EMAIL_FONT_SIZE

        word_app = word_editor.Application
        word_app.Selection.Start = len(greeting)
        time.sleep(self.SELECTION_SETTLE_DELAY_SECONDS)

        self._paste_table_with_retry(word_app)

    def _paste_table_with_retry(self, word_app):
        for _ in range(self.PASTE_RETRY_ATTEMPTS):
            try:
                word_app.Selection.Paste()
                return
            except Exception:
                time.sleep(self.PASTE_RETRY_DELAY_SECONDS)

        raise RuntimeError("Failed to paste table into email body after multiple attempts.")
