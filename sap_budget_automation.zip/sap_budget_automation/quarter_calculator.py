"""
quarter_calculator.py

Utility for determining the current fiscal quarter based on the calendar
month. Fiscal year is assumed to start in April (Apr-Jun = Q1).
"""

from datetime import date


class QuarterCalculator:
    """Calculates the current fiscal quarter (Apr-Mar fiscal year)."""

    MONTH_TO_QUARTER = {
        4: "Q1", 5: "Q1", 6: "Q1",
        7: "Q2", 8: "Q2", 9: "Q2",
        10: "Q3", 11: "Q3", 12: "Q3",
        1: "Q4", 2: "Q4", 3: "Q4",
    }

    @classmethod
    def get_current_quarter(cls):
        """Returns the current fiscal quarter as a string, e.g. 'Q2'."""
        current_month = date.today().month
        return cls.MONTH_TO_QUARTER[current_month]
