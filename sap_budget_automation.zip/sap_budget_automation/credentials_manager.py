"""
credentials_manager.py

Responsible for reading SAP and email credentials from the credentials
workbook.
"""

import os
from openpyxl import load_workbook


class CredentialsManager:
    """Reads and exposes credentials required for SAP login and email dispatch."""

    def __init__(self, credentials_file_path, logger):
        self.credentials_file_path = credentials_file_path
        self.logger = logger

    def load_credentials(self):
        """Reads credentials from the configured workbook and returns them as a dict."""
        if not os.path.exists(self.credentials_file_path):
            self.logger.error("Credentials file not found: %s", self.credentials_file_path)
            raise FileNotFoundError(f"Missing file: {self.credentials_file_path}")

        self.logger.info("Reading credentials from %s", self.credentials_file_path)
        workbook = load_workbook(self.credentials_file_path)
        worksheet = workbook.active

        credentials = {
            "SAP_PASSWORD": worksheet["H2"].value,
            "FROM_EMAIL": worksheet["E2"].value,
            "TO_EMAIL": worksheet["F2"].value,
            "CC_EMAIL": worksheet["G2"].value,
        }

        self.logger.info("Credentials loaded successfully.")
        return credentials
