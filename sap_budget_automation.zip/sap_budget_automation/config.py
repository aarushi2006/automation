"""
config.py

Centralized application configuration: file paths, SAP portal constants, and
sheet names. Handles base directory resolution for both plain-script execution
and frozen (PyInstaller .exe) execution.
"""

import os
import sys


class AppConfig:
    """Holds all file paths and application-level configuration constants."""

    def __init__(self):
        self.base_dir = self._resolve_base_dir()
        os.environ["PLAYWRIGHT_BROWSERS_PATH"] = os.path.join(self.base_dir, "browsers")

        # --- File paths ---
        self.last_run_file = os.path.join(self.base_dir, "last_run.txt")
        self.last_percent_file = os.path.join(self.base_dir, "last_percent.txt")
        self.credentials_file = os.path.join(self.base_dir, "credentials_somil.xlsx")
        self.master_file = os.path.join(self.base_dir, "Master.xlsx")
        self.sap_file = os.path.join(self.base_dir, "sap_report.xlsx")
        self.log_dir = os.path.join(self.base_dir, "logs")

        # --- SAP portal constants ---
        self.sap_url = "https://msilsapprod.maruti.co.in:44300/sap/bc/gui/sap/its/webgui?sap-client=500#"
        self.sap_user_account = "867217@maruti.co.in"
        self.sap_transaction_code = "FMAVCH01"
        self.sap_variant_name = "SOMIL17"
        self.budget_period_selector = "#M0\\:46\\:\\:\\:6\\:34"

        # --- Workbook sheet names ---
        self.master_sheet_utilization = "Utilization Summary"
        self.master_sheet_raw_report = "Raw_Report"
        self.sap_sheet_data = "Data"

    @staticmethod
    def _resolve_base_dir():
        """Returns the executable's directory when frozen, else the script's directory."""
        if getattr(sys, "frozen", False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))
