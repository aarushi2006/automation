"""
logger_setup.py

Configures application-wide logging to both the console and a timestamped
.txt log file.

Log file naming convention: Budget_Report_DDMMYYYY_HHMMSS.txt
"""

import logging
import os
from datetime import datetime


class LoggerFactory:
    """Factory responsible for creating and configuring the application logger."""

    LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
    LOG_FILE_PREFIX = "Budget_Report"

    @classmethod
    def create_logger(cls, log_directory, logger_name="BudgetAutomation"):
        """Creates (or returns an existing) logger writing to console + a fresh .txt file."""
        os.makedirs(log_directory, exist_ok=True)

        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.DEBUG)
        logger.propagate = False

        if logger.handlers:
            return logger  # Avoid duplicate handlers if called more than once

        log_file_path = cls._build_log_file_path(log_directory)
        formatter = logging.Formatter(cls.LOG_FORMAT, cls.DATE_FORMAT)

        file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)

        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)

        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

        logger.info("Logging initialized. Log file: %s", log_file_path)
        return logger

    @classmethod
    def _build_log_file_path(cls, log_directory):
        timestamp = datetime.now().strftime("%d%m%Y_%H%M%S")
        file_name = f"{cls.LOG_FILE_PREFIX}_{timestamp}.txt"
        return os.path.join(log_directory, file_name)
