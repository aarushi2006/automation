import fitz
import os

print("=== PDF Merger ===")

# Get PDF paths from user
pdf1_path = input("Enter the path of the first PDF: ").strip().strip('"')
pdf2_path = input("Enter the path of the second PDF: ").strip().strip('"')

# Check if files exist
if not os.path.exists(pdf1_path):
    print("Error: First PDF not found.")
    exit()

if not os.path.exists(pdf2_path):
    print("Error: Second PDF not found.")
    exit()

# Ask user for merge order
print("\nChoose merge order:")
print("1. First PDF + Second PDF")
print("2. Second PDF + First PDF")

choice = input("Enter your choice (1/2): ").strip()

if choice == "1":
    base_pdf = fitz.open(pdf1_path)
    second_pdf = fitz.open(pdf2_path)
elif choice == "2":
    base_pdf = fitz.open(pdf2_path)
    second_pdf = fitz.open(pdf1_path)
else:
    print("Invalid choice.")
    exit()

# Merge PDFs
base_pdf.insert_pdf(second_pdf)

# Output file
output_path = input("\nEnter output PDF path (e.g., C:/Users/Dell/Documents/Merged.pdf): ").strip().strip('"')

# Save merged PDF
base_pdf.save(output_path)

# Close PDFs
base_pdf.close()
second_pdf.close()

print(f"\nPDFs merged successfully!\nSaved at:\n{output_path}")