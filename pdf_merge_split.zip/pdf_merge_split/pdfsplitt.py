import fitz

doc = fitz.open(r"C:/Users/Dell/Downloads/MISSING PIECE - KANNADA.pdf")

num_parts = int(input("Enter number of parts: "))

for part in range(1, num_parts + 1):

    pages = input(
        f"Enter pages for Part {part}: "
    )

    page_list = [
        int(page.strip()) - 1
        for page in pages.split(",")
    ]

    new_pdf = fitz.open()

    for page_num in page_list:

        new_pdf.insert_pdf(
            doc,
            from_page=page_num,
            to_page=page_num
        )

    new_pdf.save(rf"C:\Users\Dell\Documents\study\ps\Part{part}.pdf")
    new_pdf.close()
print("PDF split successfully!")
doc.close()