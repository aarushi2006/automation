import pdfplumber
print("program started")
pdf = pdfplumber.open(
    r"C:/users/dell/Documents/study/python/finalsample.pdf"
)
for page in pdf.pages:
 text= page.extract_text()
 print("TEXT FOUND:",repr(text))
pdf.close() 
