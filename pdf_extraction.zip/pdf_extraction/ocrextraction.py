from pdf2image import convert_from_path
import pytesseract
from langdetect import detect

pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)

pdf_path = input("Enter PDF path: ")

print("\nLoading PDF...")

pages = convert_from_path(
    pdf_path,
    dpi=150,
    poppler_path=r"C:\Users\Dell\Downloads\Release-26.02.0-0\poppler-26.02.0\Library\bin"
)

print(f"Found {len(pages)} page(s).\n")

full_text = ""

for i, page in enumerate(pages, start=1):

    print(f"Processing page {i}/{len(pages)}...")

    text = pytesseract.image_to_string(
        page,
        lang="eng+jpn"
    )

    full_text += (
        f"\n\n===== PAGE {i} =====\n\n"
        + text
    )

print("\nOCR completed.")

try:
    language = detect(full_text)
    print(f"\nDetected Language: {language}")
except:
    print("\nLanguage could not be detected.")

print("\n" + "=" * 80)
print("EXTRACTED TEXT")
print("=" * 80)

print(full_text)

print("\n" + "=" * 80)
print("PROGRAM FINISHED")
print("=" * 80)  