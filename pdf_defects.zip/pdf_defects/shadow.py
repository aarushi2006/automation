from pdf2image import convert_from_path
import cv2
import numpy as np
import pymupdf

pdf_path = input("Enter PDF path: ")

print("\nLoading PDF...")

pages = convert_from_path(
    pdf_path,
    dpi=300,
    poppler_path=r"C:\Users\Dell\Downloads\Release-26.02.0-0\poppler-26.02.0\Library\bin"
)

print(f"Found {len(pages)} page(s).")

output_pdf = pymupdf.open()

for i, page in enumerate(pages, start=1):

    print(f"\nProcessing page {i}/{len(pages)}...")

    img = np.array(page)

    gray = cv2.cvtColor(
        img,
        cv2.COLOR_RGB2GRAY
    )

    # Estimate page illumination
    illumination = cv2.GaussianBlur(
        gray,
        (151, 151),
        0
    )

    shadow_score = illumination.std()

    print(
        f"Shadow Score: {shadow_score:.2f}"
    )

    if shadow_score > 15:

        print("Shadow detected. Removing shadow...")

        processed = cv2.divide(
            gray,
            illumination,
            scale=255
        )

    else:

        print("No significant shadow detected.")

        processed = gray

    _, result = cv2.threshold(
        processed,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    temp_img = f"page_{i}.png"

    cv2.imwrite(
        temp_img,
        result
    )

    height, width = result.shape

    pdf_width = width * 72 / 300
    pdf_height = height * 72 / 300

    pdf_page = output_pdf.new_page(
        width=pdf_width,
        height=pdf_height
    )

    rect = pymupdf.Rect(
        0,
        0,
        pdf_width,
        pdf_height
    )

    pdf_page.insert_image(
        rect,
        filename=temp_img
    )

    print("Page processed successfully.")

print("\nSaving output PDF...")

output_pdf.save(
    "shadow_removed.pdf"
)

output_pdf.close()

print("\nDone.")
print("Shadow-removed PDF saved as shadow_removed.pdf")