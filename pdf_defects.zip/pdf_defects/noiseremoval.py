##noise removal
from pdf2image import convert_from_path
import cv2
import numpy as np
import pymupdf

pdf_path = input("Enter PDF path: ")

print("Loading PDF...")

pages = convert_from_path(
    pdf_path,
    dpi=200,
    poppler_path=r"C:\Users\Dell\Downloads\Release-26.02.0-0\poppler-26.02.0\Library\bin"
)

print(f"Found {len(pages)} page(s).")

output_pdf = pymupdf.open()

for i, page in enumerate(pages, start=1):

    print(f"\nProcessing page {i}/{len(pages)}...")

    img = np.array(page)

    gray = cv2.cvtColor(
        img,
        cv2.COLOR_RGB2GRAY
    )

    noise_score = cv2.Laplacian(
        gray,
        cv2.CV_64F
    ).std()

    print(f"Noise Score: {noise_score:.2f}")

    if noise_score > 10:
        print("Noise detected. Cleaning page...")
        cleaned = cv2.medianBlur(
            gray,
            3
        )
    else:
        print("No significant noise detected.")
        cleaned = gray

    _, cleaned = cv2.threshold(
        cleaned,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    temp_img = f"page_{i}.png"

    cv2.imwrite(
        temp_img,
        cleaned
    )

    height, width = cleaned.shape

    pdf_width = width * 72 / 200
    pdf_height = height * 72 / 200

    pdf_page = output_pdf.new_page(
        width=pdf_width,
        height=pdf_height
    )

    rect = pymupdf.Rect(
        0,
        0,
        pdf_width,
        pdf_height
    )

    pdf_page.insert_image(
        rect,
        filename=temp_img
    )

    print("Page processed.")

output_pdf.save(
    "cleaned_output.pdf"
)

output_pdf.close()

print("\nDone.")
print("Output saved as cleaned_output.pdf")