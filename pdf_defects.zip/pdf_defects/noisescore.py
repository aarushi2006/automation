#noise score calculator 

from pdf2image import convert_from_path
import cv2
import numpy as np

pdf_path = input("Enter PDF path: ")

pages = convert_from_path(
    pdf_path,
    dpi=200,
    poppler_path=r"C:\Users\Dell\Downloads\Release-26.02.0-0\poppler-26.02.0\Library\bin"
)

total_score = 0

print("\nNOISE ANALYSIS")
print("=" * 40)

for i, page in enumerate(pages, start=1):

    img = np.array(page)

    gray = cv2.cvtColor(
        img,
        cv2.COLOR_RGB2GRAY
    )

    noise_score = cv2.Laplacian(
        gray,
        cv2.CV_64F
    ).std()

    total_score += noise_score

    print(
        f"Page {i}: Noise Score = {noise_score:.2f}"
    )

average_score = total_score / len(pages)

print("\n" + "=" * 40)
print(f"Average PDF Noise Score = {average_score:.2f}")
print("=" * 40)

if average_score < 15:
    print("Noise Level: LOW")
elif average_score < 40:
    print("Noise Level: MEDIUM")
else:
    print("Noise Level: HIGH")