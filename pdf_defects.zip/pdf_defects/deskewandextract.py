##deskews pdf and extracts text from pdf

from pdf2image import convert_from_path
import cv2
import numpy as np
import pytesseract

pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)

pdf_path = input("Enter PDF path: ")

pages = convert_from_path(
    pdf_path,
    dpi=300,
    poppler_path=r"C:\Users\Dell\Downloads\Release-26.02.0-0\poppler-26.02.0\Library\bin"
)

all_text = ""

for page_num, page in enumerate(pages, start=1):

    img = np.array(page)

    gray = cv2.cvtColor(
        img,
        cv2.COLOR_RGB2GRAY
    )

    _, thresh = cv2.threshold(
        gray,
        0,
        255,
        cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
    )

    coords = cv2.findNonZero(thresh)

    x, y, w, h = cv2.boundingRect(coords)

    cropped = gray[
        y:y+h,
        x:x+w
    ]

    thresh_crop = cv2.threshold(
        cropped,
        0,
        255,
        cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
    )[1]

    coords = np.column_stack(
        np.where(thresh_crop > 0)
    )

    angle = cv2.minAreaRect(coords)[-1]

    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle

    print(
        f"Page {page_num} Angle:",
        round(angle, 2)
    )

    h_img, w_img = cropped.shape

    center = (
        w_img // 2,
        h_img // 2
    )

    M = cv2.getRotationMatrix2D(
        center,
        angle,
        1.0
    )

    deskewed = cv2.warpAffine(
        cropped,
        M,
        (w_img, h_img),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE
    )

    deskewed = cv2.resize(
        deskewed,
        None,
        fx=2,
        fy=2,
        interpolation=cv2.INTER_CUBIC
    )

    kernel = np.array([
        [0, -1, 0],
        [-1, 5, -1],
        [0, -1, 0]
    ])

    deskewed = cv2.filter2D(
        deskewed,
        -1,
        kernel
    )

    final_img = cv2.threshold(
        deskewed,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )[1]

    cv2.imwrite(
        f"processed_page_{page_num}.png",
        final_img
    )

    text = pytesseract.image_to_string(
        final_img,
        config="--oem 3 --psm 6"
    )

    all_text += (
        f"\n\n===== PAGE {page_num} =====\n\n"
        + text
    )

print("\n" + "=" * 80)
print("EXTRACTED TEXT")
print("=" * 80)
print(all_text)